C++设计模式
什么是设计模式
“每一个模式描述了一个在我们周围不断重复发生的问题，以及该问题的解决方案的核心。这样，你就能一次又一次地使用该方案而不必做重复劳动”。 ——Christopher Alexander

如何解决复杂性？
分解
人们面对复杂性有一个常见的做法：即分而治之，将大问题分解为多个小问题，将复杂问题分解为多个简单问题。
抽象
更高层次来讲，人们处理复杂性有一个通用的技术，即抽象。由于不能掌握全部的复杂对象，我们选择忽视它的非本质细节，而去处理泛化和理想化了的对象模型。
面向对象设计原则
依赖倒置原则（DIP）
高层模块(稳定)不应该依赖于低层模块(变化)，二者都应该依赖于抽象(稳定) 。
抽象(稳定)不应该依赖于实现细节(变化) ，实现细节应该依赖于抽象(稳定)。
开放封闭原则（OCP）
对扩展开放，对更改封闭。
类模块应该是可扩展的，但是不可修改。
单一职责原则（SRP）
一个类应该仅有一个引起它变化的原因。
变化的方向隐含着类的责任。
Liskov 替换原则（LSP）
子类必须能够替换它们的基类(IS-A)。
继承表达类型抽象。
接口隔离原则（ISP）
不应该强迫客户程序依赖它们不用的方法。
接口应该小而完备。
优先使用对象组合，而不是类继承
类继承通常为“白箱复用”，对象组合通常为“黑箱复用” 。
继承在某种程度上破坏了封装性，子类父类耦合度高。
而对象组合则只要求被组合的对象具有良好定义的接口，耦合度低。
封装变化点
使用封装来创建对象之间的分界层，让设计者可以在分界层的一侧进行修改，而不会对另一侧产生不良的影响，从而实现层次间的松耦合。
针对接口编程，而不是针对实现编程
不将变量类型声明为某个特定的具体类，而是声明为某个接口。
客户程序无需获知对象的具体类型，只需要知道对象所具有的接口。
减少系统中各部分的依赖关系，从而实现“高内聚、松耦合”的类型设计方案。
从封装变化角度对模式分类
组件协作：
Template Method
Template-Pattern(Head-First版)
Observer/Event
Observer(Head-First版)
Strategy
Strategy(Head-First版)
单一职责：
Decorator
Decorator(Head-First版)
Bridge
对象创建:
Factory Method
Factory(Head-First版)
Bridge
Abstract Factory
Prototype
Builder
对象性能：
Singleton
Flyweight(享元模式)
接口隔离:
Façade(门面模式)
Proxy
Mediator(中介者)
Adapter
状态变化：
Memento(备忘录)
State
数据结构：
Composite(组合模式)
Iterator
Chain of Resposibility(职责链)
行为变化：
Command
Command(Head-First版)
Visitor
领域问题：
Interpreter
总结
现代较少用的模式
Builder
Mediator
Memento
Iterator
Chain of Resposibility
Command
Visitor
Interpreter


*******************************

organization
apply
archive
document
country
company
busimodule
barmodule
role

三、综合比较

1.聚合与组合

（1）聚合与组合都是一种结合关系，只是额外具有整体-部分的意涵。

（2）部件的生命周期不同

聚合关系中，整件不会拥有部件的生命周期，所以整件删除时，部件不会被删除。再者，多个整件可以共享同一个部件。

组合关系中，整件拥有部件的生命周期，所以整件删除时，部件一定会跟着删除。而且，多个整件不可以同时间共享同一个部件。

（3）聚合关系是"has-a"关系，组合关系是"contains-a"关系。

2.关联和聚合

（1）表现在代码层面，和关联关系是一致的，只能从语义级别来区分。

（2）关联和聚合的区别主要在语义上，关联的两个对象之间一般是平等的，例如你是我的朋友，聚合则一般不是平等的。

（3）关联是一种结构化的关系，指一种对象和另一种对象有联系。

（4）关联和聚合是视问题域而定的，例如在关心汽车的领域里，轮胎是一定要组合在汽车类中的，因为它离开了汽车就没有意义了。但是在卖轮胎的店铺业务里，就算轮胎离开了汽车，它也是有意义的，这就可以用聚合了。

3.关联和依赖

（1）关联关系中，体现的是两个类、或者类与接口之间语义级别的一种强依赖关系，比如我和我的朋友；这种关系比依赖更强、不存在依赖关系的偶然性、关系也不是临时性的，一般是长期性的，而且双方的关系一般是平等的。

（2）依赖关系中，可以简单的理解，就是一个类A使用到了另一个类B，而这种使用关系是具有偶然性的、临时性的、非常弱的，但是B类的变化会影响到A。

4.综合比较

这几种关系都是语义级别的，所以从代码层面并不能完全区分各种关系；但总的来说，后几种关系所表现的强弱程度依次为：

组合>聚合>关联>依赖

### dependency>scope
这里还要注意下scope不能随意修改，这个jar我们只是编译需要，不需要放到最终打包的war文件中，如果放入最终的war包中，启动时Mybatis会报错（具体原因是Mapper文件的namespace重名了，因为项目中有一份，jar包中还有一份）。

可以使用5个值：

compile，缺省值，适用于所有阶段，会随着项目一起发布。
provided，类似compile，期望JDK、容器或使用者会提供这个依赖。如servlet.jar。
runtime，只在运行时使用，如JDBC驱动，适用运行和测试阶段。
test，只在测试时使用，用于编译和运行测试代码。不会随项目发布。
system，类似provided，需要显式提供包含依赖的jar，Maven不会在Repository中查找它。
依赖范围控制哪些依赖在哪些classpath 中可用，哪些依赖包含在一个应用中。让我们详细看一下每一种范围：

compile （编译范围）

compile是默认的范围；如果没有提供一个范围，那该依赖的范围就是编译范围。编译范围依赖在所有的classpath 中可用，同时它们也会被打包。

provided （已提供范围）

provided 依赖只有在当JDK 或者一个容器已提供该依赖之后才使用。例如， 如果你开发了一个web 应用，你可能在编译 classpath 中需要可用的Servlet API 来编译一个servlet，但是你不会想要在打包好的WAR 中包含这个Servlet API；这个Servlet API JAR 由你的应用服务器或者servlet 容器提供。已提供范围的依赖在编译classpath （不是运行时）可用。它们不是传递性的，也不会被打包。

runtime （运行时范围）

runtime 依赖在运行和测试系统的时候需要，但在编译的时候不需要。比如，你可能在编译的时候只需要JDBC API JAR，而只有在运行的时候才需要JDBC
驱动实现。

test （测试范围）

test范围依赖 在一般的编译和运行时都不需要，它们只有在测试编译和测试运行阶段可用。

system （系统范围）

system范围依赖与provided 类似，但是你必须显式的提供一个对于本地系统中JAR 文件的路径。这么做是为了允许基于本地对象编译，而这些对象是系统类库的一部分。这样的构件应该是一直可用的，Maven 也不会在仓库中去寻找它。如果你将一个依赖范围设置成系统范围，你必须同时提供一个 systemPath 元素。注意该范围是不推荐使用的（你应该一直尽量去从公共或定制的 Maven 仓库中引用依赖）。

当我们通过maven对项目进行打包时，遇到自己的工程引用了本地的jar，通常不会将本地的jar一起打war包。这时我们可以通过maven的一个插件进行打包，这样就可以将外部的jar一起打成war包。
 <build>
        <pluginManagement>
            <plugins>
                <plugin>
                   <groupId>org.apache.maven.plugins</groupId>
                   <artifactId>maven-war-plugin</artifactId>
                        <configuration>
                         <warName>test</warName>
                            <webResources>
                                <resource>
                                    <directory>${project.basedir}/lib</directory>
                                    <targetPath>WEB-INF/lib</targetPath>
                                    <includes>
                                        <include>**/*.jar</include>
                                    </includes>
                                </resource>
                            </webResources>
                        </configuration>
                 </plugin>
            </plugins>    
        </pluginManagement>
    </build>
### Maven引入本地Jar包并打包进War包中的方法
本篇文章主要介绍了Maven引入本地Jar包并打包进War包中的方法，小编觉得挺不错的，现在分享给大家，也给大家做个参考。一起跟随小编过来看看吧
1.概述

在平时的开发中，有一些Jar包因为种种原因，在Maven的中央仓库中没有收录，所以就要使用本地引入的方式加入进来。

2. 拷贝至项目根目录

项目根目录即pom.xml文件所在的同级目录，可以在项目根目录下创建文件夹lib，如下图所示： 
![](C++设计模式_files/1.jpg)

这4个Jar包是识别网页编码所需的包。

3. 配置pom.xml，依赖本地Jar

配置Jar的dependency，包括groupId，artifactId，version三个属性，同时还要包含scope和systemPath属性，分别指定Jar包来源于本地文件，和本地文件的所在路径。

<!-- ################################# cpdetector #################################### -->
<dependency>
<groupId>cpdetector</groupId>
<artifactId>cpdetector</artifactId>
<version>1.0.10</version>
<scope>system</scope>
<systemPath>${basedir}/lib/cpdetector_1.0.10.jar</systemPath>
</dependency>
 
<dependency>
<groupId>antlr</groupId>
<artifactId>antlr</artifactId>
<version>2.7.4</version>
<scope>system</scope>
<systemPath>${basedir}/lib/antlr-2.7.4.jar</systemPath>
</dependency>
 
<dependency>
<groupId>chardet</groupId>
<artifactId>chardet</artifactId>
<version>1.0</version>
<scope>system</scope>
<systemPath>${basedir}/lib/chardet-1.0.jar</systemPath>
</dependency>
 
<dependency>
<groupId>jargs</groupId>
<artifactId>jargs</artifactId>
<version>1.0</version>
<scope>system</scope>
<systemPath>${basedir}/lib/jargs-1.0.jar</systemPath>
</dependency>
 
其中，${basedir}是指项目根路径

4. 配置Maven插件将本地Jar打包进War中

在进行以上配置以后，编写代码时已经可以引入Jar包中的class了，但是在打包时，由于scope=system,默认并不会将Jar包打进war包中，所有需要通过插件进行打包。

修改pom.xml文件，在plugins标签下加入下面的代码

<plugin>
<groupId>org.apache.maven.plugins</groupId>
<artifactId>maven-dependency-plugin</artifactId>
<version>2.10</version>
<executions>
<execution>
<id>copy-dependencies</id>
<phase>compile</phase>
<goals>
<goal>copy-dependencies</goal>
</goals>
<configuration>
<outputDirectory>${project.build.directory}/${project.build.finalName}/WEB-INF/lib</outputDirectory>
<includeScope>system</includeScope>
</configuration>
</execution>
</executions>
</plugin>
这样，打出来的war包中，就会包含本地引入的jar依赖了。

### Including and Excluding Files From the WAR
It is possible to include or exclude certain files from the WAR file, by using the <packagingIncludes> and <packagingExcludes> configuration parameters. They each take a comma-separated list of Ant file set patterns. You can use wildcards such as ** to indicate multiple directories and * to indicate an optional part of a file or directory name.

Here is an example where we exclude all JAR files from WEB-INF/lib:

<project>
  ...
  <build>
    <plugins>
      <plugin>
        <artifactId>maven-war-plugin</artifactId>
        <version>3.2.3</version>
        <configuration>
          <packagingExcludes>WEB-INF/lib/*.jar</packagingExcludes>
        </configuration>
      </plugin>
    </plugins>
  </build>
  ...
</project>

### WAR Manifest Customization
The manifest can be customized by configuring the WAR Plugin's archiver. For full information on the different configuration options available check the documentation for Maven Archiver.

Generating a manifest classpath
Generating a manifest classpath for a WAR is similar to for a JAR, but there are a couple of slight differences since you normally don't want a JAR in both the manifest classpath and the WEB-INF/lib directory. Customize the WAR Plugin's archiver:

<project>
  ...
  <build>
    <plugins>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-war-plugin</artifactId>
        <version>3.2.3</version>
        <configuration>
          <archive>
            <manifest>
              <addClasspath>true</addClasspath>
            </manifest>
          </archive>
        </configuration>
      </plugin>
      ...
    </plugins>
  </build>
  ...
</project>
Now, you can control which dependencies are included in WEB-INF/lib and in the manifest classpath by following these examples. Maven will follow the transitive dependency tree until it gets to artifacts scoped as "provided".

Note: No way is shown how to include a dependency in WEB-INF/lib but not in the manifest classpath.

<project>
  ...
  <dependencies>
    <dependency>
      <groupId>org.foo</groupId>
      <artifactId>bar-jar1</artifactId>
      <version>${pom.version}</version>
      <optional>true</optional>
      <!-- goes in manifest classpath, but not included in WEB-INF/lib -->
    </dependency>
    <dependency>
      <groupId>org.foo</groupId>
      <artifactId>bar-jar2</artifactId>
      <version>${pom.version}</version>
      <!-- goes in manifest classpath, AND included in WEB-INF/lib -->
    </dependency>
    <dependency>
      <groupId>org.foo</groupId>
      <artifactId>bar-jar3</artifactId>
      <version>${pom.version}</version>
      <scope>provided</scope>
      <!-- excluded from manifest classpath, and excluded from WEB-INF/lib -->
    </dependency>
    ...
  </dependencies>
  ...
</project>
Check the Guide to Working with Manifests for more examples.

### Adding and Filtering External Web Resources
The default resource directory for all Maven projects is src/main/resources which will end up in target/classes and in WEB-INF/classes in the WAR. The directory structure will be preserved in the process.

The WAR Plugin is also capable of including resources not found in the default resource directory through the webResources parameter.

Adding web resources
<project>
  ...
  <build>
    <plugins>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-war-plugin</artifactId>
        <version>3.2.3</version>
        <configuration>
          <webResources>
            <resource>
              <!-- this is relative to the pom.xml directory -->
              <directory>resource2</directory>
            </resource>
          </webResources>
        </configuration>
      </plugin>
    </plugins>
  </build>
  ...
</project>
Using our sample project in the usage section with an added external resource, like this:

 .
 |-- pom.xml
 |-- resource2
 |   |-- external-resource.jpg
 |   `-- image2
 |       `-- external-resource2.jpg
 `-- src
     `-- main
         |-- java
         |   `-- com
         |       `-- example
         |           `-- projects
         |               `-- SampleAction.java
         |-- resources
         |   `-- images
         |       `-- sampleimage.jpg
         `-- webapp
             |-- WEB-INF
             |   `-- web.xml
             |-- index.jsp
             `-- jsp
                 `-- websource.jsp
would end up in the WAR as:

documentedproject-1.0-SNAPSHOT.war
 |-- META-INF
 |   |-- MANIFEST.MF
 |   `-- maven
 |       `-- com.example.projects
 |           `-- documentedproject
 |               |-- pom.properties
 |               `-- pom.xml
 |-- WEB-INF
 |   |-- classes
 |   |   |-- com
 |   |   |   `-- example
 |   |   |       `-- projects
 |   |   |           `-- SampleAction.class
 |   |   `-- images
 |   |       `-- sampleimage.jpg
 |   `-- web.xml
 |-- external-resource.jpg
 |-- image2
 |   `-- external-resource2.jpg
 |-- index.jsp
 `-- jsp
     `-- websource.jsp
external-resource2.jpg and image2 are copied to the root of the WAR, preserving the directory structure.

Configuring web Resources
webResources is a list of resources. All options of resource are supported.

A web resource

can have includes/excludes
can be filtered
is not limited to the default destination - the root of the WAR
Includes/Excludes
To include all jpgs in the WAR we can add the following to our POM configuration from above:

        ...
        <configuration>
          <webResources>
            <resource>
              <!-- this is relative to the pom.xml directory -->
              <directory>resource2</directory>
              <!-- the list has a default value of ** -->
              <includes>
                <include>**/*.jpg</include>
              </includes>
            </resource>
          </webResources>
        </configuration>
        ...
To exclude the image2 directory from the WAR add this:

        ...
        <configuration>
          <webResources>
            <resource>
              <!-- this is relative to the pom.xml directory -->
              <directory>resource2</directory>
              <!-- there's no default value for this -->
              <excludes>
                <exclude>**/image2</exclude>
              </excludes>
            </resource>
          </webResources>
        </configuration>
        ...
Be careful when mixing includes and excludes, excludes will have a higher priority. Includes can not override excludes if a resource matches both.

Having this configuration will exclude all jpgs from the WAR:

        ...
        <configuration>
          <webResources>
            <resource>
              <!-- this is relative to the pom.xml directory -->
              <directory>resource2/</directory>
              <!-- the list has a default value of ** -->
              <includes>
                <include>image2/*.jpg</include>
              </includes>
              <!-- there's no default value for this -->
              <excludes>
                <exclude>**/*.jpg</exclude>
              </excludes>
            </resource>
          </webResources>
        </configuration>
        ...
Here's another example of how to specify include and exclude patterns:

        ...
        <configuration>
          <webResources>
            <resource>
              <!-- this is relative to the pom.xml directory -->
              <directory>resource2</directory>
              <!-- the default value is ** -->
              <includes>
                <include>**/pattern1</include>
                <include>*pattern2</include>
              </includes>
              <!-- there's no default value for this -->
              <excludes>
                <exclude>*pattern3/pattern3</exclude>
                <exclude>pattern4/pattern4</exclude>
              </excludes>
            </resource>
          </webResources>
        </configuration>
        ...
Filtering
Using our example above, we can also configure filters for our resources. We will add a hypothetical configurations directory to our project:

 .
 |-- configurations
 |   |-- config.cfg
 |   `-- properties
 |       `-- config.prop
 |-- pom.xml
 |-- resource2
 |   |-- external-resource.jpg
 |   `-- image2
 |       `-- external-resource2.jpg
 `-- src
     `-- main
         |-- java
         |   `-- com
         |       `-- example
         |           `-- projects
         |               `-- SampleAction.java
         |-- resources
         |   `-- images
         |       `-- sampleimage.jpg
         `-- webapp
             |-- WEB-INF
             |   `-- web.xml
             |-- index.jsp
             `-- jsp
                 `-- websource.jsp
To prevent corrupting your binary files when filtering is enabled, you can configure a list of file extensions that will not be filtered.

        ...
        <configuration>
          <!-- the default value is the filter list under build -->
          <!-- specifying a filter will override the filter list under build -->
          <filters>
            <filter>properties/config.prop</filter>
          </filters>
          <nonFilteredFileExtensions>
            <!-- default value contains jpg,jpeg,gif,bmp,png -->
            <nonFilteredFileExtension>pdf</nonFilteredFileExtension>
          </nonFilteredFileExtensions>
          <webResources>
            <resource>
              <directory>resource2</directory>
              <!-- it's not a good idea to filter binary files -->
              <filtering>false</filtering>
            </resource>
            <resource>
              <directory>configurations</directory>
              <!-- enable filtering -->
              <filtering>true</filtering>
              <excludes>
                <exclude>**/properties</exclude>
              </excludes>
            </resource>
          </webResources>
        </configuration>
        ...
config.prop
interpolated_property=some_config_value
config.cfg
<another_ioc_container>
   <configuration>${interpolated_property}</configuration>
</another_ioc_container>
The resulting WAR would be:

documentedproject-1.0-SNAPSHOT.war
 |-- META-INF
 |   |-- MANIFEST.MF
 |   `-- maven
 |       `-- com.example.projects
 |           `-- documentedproject
 |               |-- pom.properties
 |               `-- pom.xml
 |-- WEB-INF
 |   |-- classes
 |   |   |-- com
 |   |   |   `-- example
 |   |   |       `-- projects
 |   |   |           `-- SampleAction.class
 |   |   `-- images
 |   |       `-- sampleimage.jpg
 |   `-- web.xml
 |-- config.cfg
 |-- external-resource.jpg
 |-- image2
 |   `-- external-resource2.jpg
 |-- index.jsp
 `-- jsp
     `-- websource.jsp
and the content of config.cfg would be:

<another_ioc_container>
   <configuration>some_config_value</configuration>
</another_ioc_container>
Note: In versions 2.2 and earlier of this plugin the platform encoding was used when filtering resources. Depending on what that encoding was you could end up with scrambled characters after filtering. Starting with version 2.3 this plugin respects the property project.build.sourceEncoding when filtering resources. One notable exception to this is that .xml files are filtered using the encoding specified inside the xml-file itself.

Overriding the default destination directory
By default web resources are copied to the root of the WAR, as shown in the previous example. To override the default destination directory, specify the target path.

        ...
        <configuration>
          <webResources>
            <resource>
              ...
            </resource>
            <resource>
              <directory>configurations</directory>
              <!-- override the destination directory for this resource -->
              <targetPath>WEB-INF</targetPath>
              <!-- enable filtering -->
              <filtering>true</filtering>
              <excludes>
                <exclude>**/properties</exclude>
              </excludes>
            </resource>
          </webResources>
        </configuration>
        ...
Using the sample project the resulting WAR would look like this:

documentedproject-1.0-SNAPSHOT.war
 |-- META-INF
 |   |-- MANIFEST.MF
 |   `-- maven
 |       `-- com.example.projects
 |           `-- documentedproject
 |               |-- pom.properties
 |               `-- pom.xml
 |-- WEB-INF
 |   |-- classes
 |   |   |-- com
 |   |   |   `-- example
 |   |   |       `-- projects
 |   |   |           `-- SampleAction.class
 |   |   `-- images
 |   |       `-- sampleimage.jpg
 |   |-- config.cfg
 |   `-- web.xml
 |-- external-resource.jpg
 |-- image2
 |   `-- external-resource2.jpg
 |-- index.jsp
 `-- jsp
     `-- websource.jsp
	 
	 
### 例子
<build> 
  <finalName>communitytag</finalName> 
  <plugins> 
    <plugin> 
      <groupId>org.apache.maven.plugins</groupId> 
      <artifactId>maven-war-plugin</artifactId> 
      <version>2.1-alpha-1</version> 
      <configuration> 
        <!-- 
          打包之前过滤掉不想要被打进 .war包的jar,注意：这个地方，本来路径应该是 
          WEB-INF/lib/anaalyzer-2.0.4.jar,但是经过多次试验,不能这样，至于咋回事儿，搞不清楚。。经多方查证均无结果 
          暂且这样吧，虽然显得很丑陋，但是总能解决问题吧 
        --> 
        <warSourceExcludes>*/lib/analyzer-2.0.4.jar</warSourceExcludes> 
        <webResources> 
          <resource> 
            <!-- 元配置文件的目录，相对于pom.xml文件的路径 --> 
            <directory>src/main/webapp/WEB-INF</directory> 

            <!-- 是否过滤文件，也就是是否启动auto-config的功能 --> 
            <filtering>true</filtering> 

            <!-- 目标路径 --> 
            <targetPath>WEB-INF</targetPath> 
          </resource> 
        </webResources> 
      </configuration> 
    </plugin> 
  </plugins> 
</build> 

## 插件管理

        插件管理与依赖管理原理一样、不同的是定义的元素标签不一样、插件管理标签是build标签的子标签pluginManagement、在父POM中定义、子POM引用。如前面有个生成源码包的插件、使用插件管理的配置过程如下：

        a）父POM——scattered-items中的pom.xml：

    <build>
        <pluginManagement>
            <plugins>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-source-plugin</artifactId>
                    <version>${sources.plugin.verion}</version>
                    <executions>
                        <execution>
                            <id>attach-sources</id>
                            <phase>verify</phase>
                            <goals>
                                <goal>jar-no-fork</goal>
                            </goals>
                        </execution>
                    </executions>
                </plugin>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-compiler-plugin</artifactId>
                    <version>3.1</version>
                    <configuration>
                        <source>1.7</source>
                        <target>1.7</target>
                    </configuration>
                </plugin>
            </plugins>
        </pluginManagement>
    </build>
        b）子POM——items-thkinjava中的pom.xml:

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-source-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
        注意的东西与依赖管理类似、只是换成了插件管理。
--------------------- 
版权声明：本文为CSDN博主「AlienStar」的原创文章，遵循CC 4.0 by-sa版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/crave_shy/article/details/40923721